SRVK Portfolio

Open index.html in a browser. The profile image is in assets/profile.jpg.
The content is based on the supplied SRVK - CV.docx.
